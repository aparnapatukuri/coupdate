package com.niit.collaboration.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "ADMIN_FORUM")
@Component
public class Forum {
	@Id
	@Column(name="id")
	private int Forum_id;
	private String category;
	private String title;
	private String content;
	private Date Forum_date;
	private String Forum_user;
	public int getForum_id() {
		return Forum_id;
	}
	public void setForum_id(int forum_id) {
		Forum_id = forum_id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getForum_date() {
		return Forum_date;
	}
	public void setForum_date(Date forum_date) {
		Forum_date = forum_date;
	}
	public String getForum_user() {
		return Forum_user;
	}
	public void setForum_user(String forum_user) {
		Forum_user = forum_user;
	}
	
	
	
}
