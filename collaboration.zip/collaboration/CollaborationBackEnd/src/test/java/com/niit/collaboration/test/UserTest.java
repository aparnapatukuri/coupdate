package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.UserDAO;
import com.niit.collaboration.model.User;

public class UserTest {
public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.collaboration");
		context.refresh();
		
		 UserDAO userDAO = (UserDAO)context.getBean("userDAO");
		User u = (User)context.getBean("user");
		
	  
	    u.setUserId("mary");
	    u.setUserName("niba");
	    u.setPassword("maryniba");
	    u.setMail("nibarithi@gmail.com");
	    
	    u.setAddress("aaaaa");
	    u.setRole("active");
	    u.setContact("9626550126");
	    
	   
	    userDAO.saveOrUpdate(u);
		
		
	}

}
