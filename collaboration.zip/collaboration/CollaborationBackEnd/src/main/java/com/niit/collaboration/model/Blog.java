package com.niit.collaboration.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "ADMIN_BLOG")
@Component

public class Blog {
	
	@Id
	@Column(name="id")
	private int blog_id;
	
	private String title;
	private String content;
	private Date blog_date;
	private String blog_user;
	
	
	
	public int getBlog_id() {
		return blog_id;
	}
	public void setBlog_id(int blog_id) {
		this.blog_id = blog_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	public Date getBlog_date() {
		return blog_date;
	}
	public void setBlog_date(Date blog_date) {
		this.blog_date = blog_date;
	}
	public String getBlog_user() {
		return blog_user;
	}
	public void setBlog_user(String blog_user) {
		this.blog_user = blog_user;
	}
	
	

}
