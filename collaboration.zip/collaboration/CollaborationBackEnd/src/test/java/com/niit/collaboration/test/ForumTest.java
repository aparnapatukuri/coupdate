package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.ForumDAO;
import com.niit.collaboration.dao.UserDAO;
import com.niit.collaboration.model.Forum;
import com.niit.collaboration.model.User;

public class ForumTest {
public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.collaboration");
		context.refresh();
		
		Forum f = (Forum)context.getBean("forum");
		
	  
	    f.setForum_id(275);
	    f.setCategory("x");
	    f.setTitle("apa");
	    f.setContent("gfhh");
	    f.setForum_date(8/18/2016);
	    f.setForum_user("jhj");
	    
	    
	    
	    
	    
	    ForumDAO forumDAO = (ForumDAO)context.getBean("forumDAO");
	    forumDAO.saveOrUpdate(f);
		
		
	}



}
